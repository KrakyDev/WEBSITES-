# Add this to your database 'rfid_db' using the SQL tab in phpMyAdmin
# This is the command that creates your table and adds the 'uid' and 'name' columns

CREATE TABLE IF NOT EXISTS rfid_scans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid VARCHAR(50) NOT NULL,
    name VARCHAR(100),
    emp_id VARCHAR(50),
    position VARCHAR(100),
    scan_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
