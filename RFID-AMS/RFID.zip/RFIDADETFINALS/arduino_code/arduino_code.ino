#include <SPI.h>
#include <MFRC522.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define SS_PIN 10
#define RST_PIN 9
MFRC522 myRFID(SS_PIN, RST_PIN);


LiquidCrystal_I2C lcd(0x27, 16, 2);

int pinLED = 2;
int pinBuzzer = 3;  

void setup() 
{
  Serial.begin(9600);
  SPI.begin();
  myRFID.PCD_Init();
 
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Scan your card");

  Serial.println("Ready - Scan your card or tag...");
  Serial.println("========================");
  
  pinMode(pinLED, OUTPUT);
  pinMode(pinBuzzer, OUTPUT); 

  // Startup Test Beep (Verifies hardware on Pin 3)
  digitalWrite(pinBuzzer, HIGH);
  delay(200);
  digitalWrite(pinBuzzer, LOW);
}

void loop() 
{
  if (!myRFID.PICC_IsNewCardPresent()) 
  {
    return;
  }

  if (!myRFID.PICC_ReadCardSerial()) 
  {
    return;
  }

  digitalWrite(pinLED, HIGH);
  

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Checking...");

  String content = "";
  for (byte i = 0; i < myRFID.uid.size; i++) 
  {
    content.concat(String(myRFID.uid.uidByte[i] < 0x10 ? " 0" : " "));
    content.concat(String(myRFID.uid.uidByte[i], HEX));
  }
  content.toUpperCase();

  Serial.println("Card/Tag Detected!");
  Serial.print("UID:");
  Serial.println(content);


  String pyResponse = "";
  long startTime = millis();
  while(millis() - startTime < 1500) {
    if (Serial.available() > 0) {
      pyResponse = Serial.readStringUntil('\n');
      pyResponse.trim();
      break;
    }
  }

 
  if (pyResponse == "REGISTERED") {
    
    digitalWrite(pinBuzzer, HIGH);
    delay(150);
    digitalWrite(pinBuzzer, LOW);
    
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("ACCESS GRANTED");
    lcd.setCursor(0, 1);
    lcd.print(content);
    delay(850);
  } 
  else if (pyResponse == "UNREGISTERED") {
    
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("UNREGISTERED");
    lcd.setCursor(0, 1);
    lcd.print("Access Denied");

    
    for (int i = 0; i < 10; i++) {
      digitalWrite(pinBuzzer, HIGH);
      delay(150);
      digitalWrite(pinBuzzer, LOW);
      delay(150);
    }
  }
  else {
    
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("System Error");
    lcd.setCursor(0, 1);
    lcd.print("App Offline");
    
    
    for (int i = 0; i < 4; i++) {
      digitalWrite(pinBuzzer, HIGH);
      delay(150);
      digitalWrite(pinBuzzer, LOW);
      delay(150);
    }
  }

  digitalWrite(pinLED, LOW);
  Serial.println("========================");

  
  delay(1500);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Scan your card");
  
  
  myRFID.PICC_HaltA();
  myRFID.PCD_StopCrypto1();
}
