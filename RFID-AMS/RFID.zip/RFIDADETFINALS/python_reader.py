import serial
import mysql.connector
import time
import json
import os

# 1. Load Dictionary Mapping UIDs to Names from a file
# This file 'users.json' will be created automatically in your folder
# and will store your names FOREVER!
script_dir = os.path.dirname(os.path.abspath(__file__))
USERS_FILE = os.path.join(script_dir, 'users.json')

if os.path.exists(USERS_FILE):
    with open(USERS_FILE, 'r') as f:
        users_dictionary = json.load(f)
else:
    # Default users if the file doesn't exist yet
    users_dictionary = {
        "33 E5 63 06": "John Carlo S. Belista",
        "A2 C0 F0 06": "Sander Bermundo",
        "F4 8B 63 06": "Sonny Tacanega"  
    }
    with open(USERS_FILE, 'w') as f:
        json.dump(users_dictionary, f, indent=4)

def save_users_forever():
    """Immediately saves any new names to the users.json file forever!"""
    with open(USERS_FILE, 'w') as f:
        json.dump(users_dictionary, f, indent=4)

# 2. Connect to MySQL database
try:
    db = mysql.connector.connect(
        host="localhost",
        user="root",
        password="", 
        database="rfid_db"
    )
    cursor = db.cursor()
    print(f"Connected to phpMyAdmin database (rfid_db) successfully!")
    print(f"Currently tracking {len(users_dictionary)} users from your users.json file!")
except Exception as e:
    print(f"Database connection failed. Make sure XAMPP/WAMP MySQL is running!\nError: {e}")
    exit()

# 3. Connect to Arduino on COM6
try:
    ser = serial.Serial('COM6', 9600, timeout=1)
    time.sleep(2) # Wait for the Arduino to initialize
    print("\nListening to Arduino on COM6... Waiting for a card scan.")
except Exception as e:
    print(f"Failed to connect to COM6. Make sure the Arduino Serial Monitor is CLOSED!\nError: {e}")
    exit()

# 4. Read data and save Name + UID to database
while True:
    try:
        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8', errors='ignore').strip()
            
            if "UID:" in line:
                uid = line.replace("UID:", "").strip()
                
                # Check if this UID exists in our dictionary
                if uid in users_dictionary:
                    name = users_dictionary[uid]
                    print(f"\n[Scanned] Welcome, {name}! (UID: {uid})")
                else:
                    print(f"\n[Scanned] Unknown User Tapped! (UID: {uid})")
                    choice = input("Do you want to register this user? (Y/n): ").strip().upper()
                    
                    if choice == 'Y' or choice == '':
                        # Register them
                        new_name = input(f"Enter the specific Name for card {uid}: ").strip()
                        
                        users_dictionary[uid] = new_name # Save it in memory
                        save_users_forever()             # SAVE IT TO THE FILE FOREVER
                        
                        name = new_name
                        print(f" -> Successfully registered '{name}' linking to card: {uid}!")
                    else:
                        name = "Unknown User"
                        print(" -> Proceeding as Unknown User.")
                
                # Insert both UID and Name into database
                try:
                    sql = "INSERT INTO rfid_scans (uid, name) VALUES (%s, %s)"
                    val = (uid, name)
                    cursor.execute(sql, val)
                    db.commit()
                    print(f" -> SUCCESS: Saved '{name}' to database!")
                except Exception as e:
                    print(f" -> ERROR: Failed to save to database: {e}")
    except Exception as general_e:
        print(f"An unexpected error occurred: {general_e}")
