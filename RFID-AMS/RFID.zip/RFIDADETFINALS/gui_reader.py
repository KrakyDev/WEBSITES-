import serial
import mysql.connector
import time
import json
import os
import datetime
import tkinter as tk
from tkinter import ttk, messagebox, font
from PIL import Image, ImageTk

# Premium Dark Mode Theme Colors
BG_MAIN = "#121212"
BG_SEC = "#1E1E1E"
FG_MAIN = "#FFFFFF"
FG_SEC = "#B3B3B3"
ACCENT = "#3D5AFE"
ERROR_COLOR = "#F44336"
SUCCESS_COLOR = "#4CAF50"
CARD_BG = "#FAFAFA"
CARD_TXT = "#121212"

class EmployeeRFIDReaderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("RFID Card Reader System - Offline")
        self.root.geometry("900x750")
        self.root.configure(bg=BG_MAIN)
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # Load Modern Fonts
        try:
            self.title_font = font.Font(family="Inter", size=26, weight="bold")
            self.heading_font = font.Font(family="Inter", size=14)
            self.text_font = font.Font(family="Inter", size=12)
            self.bold_text_font = font.Font(family="Inter", size=12, weight="bold")
            self.id_font = font.Font(family="Inter", size=20, weight="bold")
        except:
            # Fallback to Segoe UI/Helvetica if Inter is not installed
            self.title_font = font.Font(family="Segoe UI", size=26, weight="bold")
            self.heading_font = font.Font(family="Segoe UI", size=14)
            self.text_font = font.Font(family="Segoe UI", size=12)
            self.bold_text_font = font.Font(family="Segoe UI", size=12, weight="bold")
            self.id_font = font.Font(family="Segoe UI", size=20, weight="bold")

        # System Files (Offline Capability)
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.users_file = os.path.join(self.script_dir, 'users.json')
        self.load_users()
        
        # State Machine for Time In / Time Out
        self.attendance_log = {} # maps uid -> {"state", "time_in", "time_out"}

        # Offline Local Database Connection
        self.db = None
        self.cursor = None
        self.connect_db()

        # Serial Connection
        self.ser = None
        self.connect_serial()

        # Secondary UI State
        self.profile_window = None
        self.uid_label_prof = None
        self.name_label_prof = None
        self.time_in_val = None
        self.time_out_val = None
        self.status_lbl = None
        self.is_busy = False # concurrency protection

        # Build Primary Window UI
        self.build_main_ui()

        # Fetch records automatically upon start
        self.refresh_grid()

        # Start Polling Serial asynchronously in Tkinter
        self.root.after(200, self.check_serial)

    def load_users(self):
        """Loads offline users mapping from JSON with migration support."""
        if os.path.exists(self.users_file):
            try:
                with open(self.users_file, 'r') as f:
                    self.users_dictionary = json.load(f)
                
                # Migration: Convert old string values to object format
                migrated = False
                for uid, data in self.users_dictionary.items():
                    if isinstance(data, str):
                        self.users_dictionary[uid] = {
                            "name": data,
                            "id": "N/A",
                            "position": "N/A"
                        }
                        migrated = True
                if migrated:
                    self.save_users()
            except Exception as e:
                print(f"Error loading users: {e}")
                self.users_dictionary = {}
        else:
            self.users_dictionary = {}
            self.save_users()

    def save_users(self):
        """Saves mappings to JSON"""
        with open(self.users_file, 'w') as f:
            json.dump(self.users_dictionary, f, indent=4)

    def connect_db(self):
        """Connects to Local MySQL XAMPP Offline"""
        try:
            self.db = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="rfid_db"
            )
            self.cursor = self.db.cursor()
            
            # Auto-update database schema for new columns if they don't exist
            try:
                # Ensure table exists first with basic columns
                self.cursor.execute("""CREATE TABLE IF NOT EXISTS rfid_scans (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    uid VARCHAR(50) NOT NULL,
                    name VARCHAR(100),
                    scan_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )""")
                self.db.commit()
                
                # Individually try to add columns (will fail gracefully if they exist)
                try:
                    self.cursor.execute("ALTER TABLE rfid_scans ADD COLUMN emp_id VARCHAR(50) AFTER name")
                    self.db.commit()
                except: pass
                
                try:
                    self.cursor.execute("ALTER TABLE rfid_scans ADD COLUMN position VARCHAR(100) AFTER emp_id")
                    self.db.commit()
                except: pass
                
            except Exception as e:
                print("Schema update error:", e)
            
        except Exception as e:
            print("DB Connect Error:", e)
            self.db = None

    def connect_serial(self):
        """Establish serial comms with Arduino"""
        try:
            self.ser = serial.Serial('COM6', 9600, timeout=0.1)
            # Give Arduino 2 seconds to reboot upon connection
            time.sleep(2) 
        except Exception as e:
            self.ser = None

    def get_logo_image(self, width=None):
        """Helper to load image robustly using PIL"""
        possible_names = ["OLFU_official_logo.png", "OLFU_official_logo.png.png", "logo.png"]
        for img_name in possible_names:
            logo_path = os.path.join(self.script_dir, img_name)
            if os.path.exists(logo_path):
                try:
                    img = Image.open(logo_path).convert("RGBA")
                    if width:
                        wpercent = (width / float(img.size[0]))
                        hsize = int((float(img.size[1]) * float(wpercent)))
                        img = img.resize((width, hsize), Image.Resampling.LANCZOS)
                    return ImageTk.PhotoImage(img)
                except Exception as e:
                    print("PIL Load Error:", e)
        return None

    def build_main_ui(self):
        # Header Graphic area
        header_frame = tk.Frame(self.root, bg=BG_SEC)
        header_frame.pack(fill="x")
        
        # Robust Pillow Logo rendering
        self.main_logo = self.get_logo_image(width=160)
        if self.main_logo:
            lbl_logo = tk.Label(header_frame, image=self.main_logo, bg=BG_SEC)
            lbl_logo.pack(pady=(15, 5))
                
        lbl_title = tk.Label(header_frame, text="RFID Management System", font=self.title_font, bg=BG_SEC, fg=ACCENT)
        lbl_title.pack(pady=(5, 5))
        
        db_status = "Connected (Local)" if self.db else "Offline (JSON Mode Only)"
        lbl_sub = tk.Label(header_frame, text=f"Database Status: {db_status}", font=self.text_font, bg=BG_SEC, fg=FG_SEC)
        lbl_sub.pack(pady=(0, 15))

        # Status Tracking
        self.status_var = tk.StringVar(value=f"Waiting for Card...\nCurrently Tracking: {len(self.users_dictionary)} Employees")
        
        content_frame = tk.Frame(self.root, bg=BG_MAIN)
        content_frame.pack(fill="x", pady=10)
        
        status_display = tk.Label(content_frame, textvariable=self.status_var, font=self.heading_font, bg=BG_MAIN, fg=FG_MAIN, justify="center")
        status_display.pack()
        
        # Admin Actions Frame
        admin_frame = tk.Frame(self.root, bg=BG_MAIN)
        admin_frame.pack(fill="x", pady=(0, 10))
        
        unregister_btn = tk.Button(admin_frame, text="Unregister Employee", command=self.prompt_unregister, 
                                   bg=ERROR_COLOR, fg=FG_MAIN, font=self.text_font, relief="flat", padx=10, pady=2)
        unregister_btn.pack()
        
        # ====== TREEVIEW DATA GRID ======
        grid_frame = tk.Frame(self.root, bg=BG_MAIN)
        grid_frame.pack(expand=True, fill="both", padx=30, pady=(10, 20))
        
        # Treeview styling (Make it beautiful)
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Treeview", 
                        background=BG_SEC, 
                        foreground=FG_MAIN, 
                        rowheight=30, 
                        fieldbackground=BG_SEC,
                        borderwidth=0)
        style.map("Treeview", background=[("selected", ACCENT)])
        style.configure("Treeview.Heading", 
                        background="#333333", 
                        foreground=FG_MAIN, 
                        font=self.bold_text_font,
                        relief="flat")
                        
        tree_scroll = tk.Scrollbar(grid_frame)
        tree_scroll.pack(side="right", fill="y")
        
        self.tree = ttk.Treeview(grid_frame, yscrollcommand=tree_scroll.set, selectmode="extended")
        self.tree.pack(expand=True, fill="both")
        tree_scroll.config(command=self.tree.yview)
        
        self.tree['columns'] = ("ID", "UID", "Name", "EmpID", "Pos", "Scan Time")
        self.tree.column("#0", width=0, stretch="no")
        self.tree.column("ID", anchor="center", width=50)
        self.tree.column("UID", anchor="center", width=110)
        self.tree.column("Name", anchor="w", width=180)
        self.tree.column("EmpID", anchor="center", width=110)
        self.tree.column("Pos", anchor="w", width=120)
        self.tree.column("Scan Time", anchor="center", width=180)

        self.tree.heading("#0", text="", anchor="w")
        self.tree.heading("ID", text="ID", anchor="center")
        self.tree.heading("UID", text="Card UID", anchor="center")
        self.tree.heading("Name", text="Employee Name", anchor="center")
        self.tree.heading("EmpID", text="Employee ID", anchor="center")
        self.tree.heading("Pos", text="Position", anchor="center")
        self.tree.heading("Scan Time", text="Log Timestamp", anchor="center")

        # Indicator Footer
        footer = tk.Frame(self.root, bg=BG_SEC, height=40)
        footer.pack(fill="x", side="bottom")
        
        conn_text = " Arduino Connected (COM6) " if self.ser else " Arduino DISCONNECTED "
        conn_color = SUCCESS_COLOR if self.ser else ERROR_COLOR
        tk.Label(footer, text=conn_text, font=("Segoe UI", 10, "bold"), bg=conn_color, fg=FG_MAIN).pack(side="left", padx=10, fill="y")

    def refresh_grid(self):
        """Fetches ALL historical data directly from the offline MySQL Database"""
        if not self.db:
            
            # If no DB, insert a dummy row to represent mode
            for item in self.tree.get_children():
                self.tree.delete(item)
            self.tree.insert(parent='', index='end', iid="error", text='', values=("-", "-", "Offline Mode. DB Unreachable.", "-"))
            return
            
        # clear tree
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        try:
            self.db.ping(reconnect=True, attempts=1, delay=0)
            # Fetch entire history in descending order
            self.cursor.execute("SELECT id, uid, name, emp_id, position, scan_time FROM rfid_scans ORDER BY id DESC")
            records = self.cursor.fetchall()
            for record in records:
                self.tree.insert(parent='', index='end', iid=record[0], text='', values=(record[0], record[1], record[2], record[3], record[4], record[5]))
        except Exception as e:
            print("DB Fetch Error:", e)

    def check_serial(self):
        """Non-blocking asynchronous serial checker."""
        # Only poll if not currently processing another card/dialog
        if self.is_busy:
            self.root.after(100, self.check_serial)
            return

        if self.ser and self.ser.in_waiting > 0:
            try:
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                if "UID:" in line:
                    uid = line.replace("UID:", "").strip()
                    self.is_busy = True # Set busy before processing
                    self.process_card(uid)
            except Exception as e:
                print("Serial error:", e)
                self.is_busy = False
        
        # re-schedule serial poll
        self.root.after(100, self.check_serial)

    def process_card(self, uid):
        try:
            # 1. Verification
            if uid in self.users_dictionary:
                user_data = self.users_dictionary[uid]
                name = user_data["name"]
                
                # Send permission to Arduino -> TRIGGERS BUZZER
                if self.ser:
                    self.ser.write(b"REGISTERED\n") 
                
                # 2. Time In / Time Out Logic
                now = datetime.datetime.now()
                time_str = now.strftime("%m/%d/%Y - %I:%M:%S %p")
                
                if uid not in self.attendance_log:
                    # 1st Tap -> IN
                    self.attendance_log[uid] = {"state": "IN", "time_in": time_str, "time_out": "--"}
                else:
                    if self.attendance_log[uid]["state"] == "IN":
                        # 2nd Tap -> OUT
                        self.attendance_log[uid]["state"] = "OUT"
                        self.attendance_log[uid]["time_out"] = time_str
                    else:
                        # 3rd Tap -> Reset to IN
                        self.attendance_log[uid] = {"state": "IN", "time_in": time_str, "time_out": "--"}
                        
                card_record = self.attendance_log[uid]

                # Save local history
                self.log_scan(uid, name, user_data.get("id", "N/A"), user_data.get("position", "N/A"))
                
                # Show secondary profile window
                self.show_profile(uid, name, card_record, user_data)
                self.status_var.set(f"TIMED {card_record['state']}!\n{name}")
            else:
                # Send rejection to Arduino -> NO BUZZER
                if self.ser:
                    self.ser.write(b"UNREGISTERED\n") 
                
                self.status_var.set(f"ACCESS DENIED\nUnregistered Tag: {uid}")
                self.prompt_registration(uid)
        
        except Exception as e:
            print(f"Error processing card: {e}")
            self.status_var.set(f"System Error\nCheck Console")
        
        finally:
            # Clear any backlog that accumulated during the dialog/processing
            if self.ser:
                try:
                    self.ser.reset_input_buffer()
                except:
                    pass
            # Release the lock
            self.is_busy = False

    def log_scan(self, uid, name, emp_id="N/A", position="N/A"):
        """Logs into XAMPP when available and immediately refreshes the Grid"""
        if self.db:
            try:
                # Ensure connection is kept alive
                self.db.ping(reconnect=True, attempts=1, delay=0)
                sql = "INSERT INTO rfid_scans (uid, name, emp_id, position) VALUES (%s, %s, %s, %s)"
                val = (uid, name, emp_id, position)
                self.cursor.execute(sql, val)
                self.db.commit()
                
                # Fetch new data and update Grid immediately
                self.refresh_grid()
                
            except Exception as e:
                print(f"Failed DB log logging: {e}")

    def show_profile(self, uid, name, card_record=None, user_data=None):
        """Create or Dynamically Update the Secondary Profile Window"""
        if card_record is None:
            card_record = {"state": "VERIFIED", "time_in": "--", "time_out": "--"}
        
        if user_data is None:
            user_data = self.users_dictionary.get(uid, {"id": "N/A", "position": "N/A"})
            
        status_text = "TIMED IN" if card_record["state"] == "IN" else "TIMED OUT"
        status_color = SUCCESS_COLOR if card_record["state"] == "IN" else "#F57C00"
        
        if self.profile_window is None or not tk.Toplevel.winfo_exists(self.profile_window):
            self.profile_window = tk.Toplevel(self.root)
            self.profile_window.title(f"EMPLOYEE ID - {name}")
            self.profile_window.geometry("550x520")
            self.profile_window.configure(bg=BG_SEC)
            
            # Create Card Layout
            card_frame = tk.Frame(self.profile_window, bg=CARD_BG, highlightbackground="#ccc", highlightthickness=1)
            card_frame.pack(expand=True, fill="both", padx=30, pady=30)
            
            # Profile Logo rendering using PIL
            self.prof_logo = self.get_logo_image(width=80)
            if self.prof_logo:
                lbl_prof_logo = tk.Label(card_frame, image=self.prof_logo, bg=CARD_BG)
                lbl_prof_logo.pack(pady=(15, 0))
            
            header = tk.Label(card_frame, text="EMPLOYEE PROFILE", font=("Segoe UI", 16, "bold"), bg=CARD_BG, fg="#555")
            header.pack(pady=(10, 15))

            info_frame = tk.Frame(card_frame, bg=CARD_BG)
            info_frame.pack(fill="x", padx=30)

            tk.Label(info_frame, text="FULL NAME:", font=self.bold_text_font, bg=CARD_BG, fg="#888").grid(row=0, column=0, sticky="w", pady=2)
            self.name_label_prof = tk.Label(info_frame, text=name, font=self.heading_font, bg=CARD_BG, fg=CARD_TXT)
            self.name_label_prof.grid(row=0, column=1, sticky="w", padx=10, pady=2)
            
            tk.Label(info_frame, text="EMP ID:", font=self.bold_text_font, bg=CARD_BG, fg="#888").grid(row=1, column=0, sticky="w", pady=2)
            self.empid_label_prof = tk.Label(info_frame, text=user_data.get("id", "N/A"), font=self.text_font, bg=CARD_BG, fg=CARD_TXT)
            self.empid_label_prof.grid(row=1, column=1, sticky="w", padx=10, pady=2)

            tk.Label(info_frame, text="POSITION:", font=self.bold_text_font, bg=CARD_BG, fg="#888").grid(row=2, column=0, sticky="w", pady=2)
            self.pos_label_prof = tk.Label(info_frame, text=user_data.get("position", "N/A"), font=self.text_font, bg=CARD_BG, fg=CARD_TXT)
            self.pos_label_prof.grid(row=2, column=1, sticky="w", padx=10, pady=2)

            tk.Label(info_frame, text="CARD UID:", font=self.bold_text_font, bg=CARD_BG, fg="#888").grid(row=3, column=0, sticky="w", pady=2)
            self.uid_label_prof = tk.Label(info_frame, text=uid, font=self.text_font, bg=CARD_BG, fg=FG_SEC)
            self.uid_label_prof.grid(row=3, column=1, sticky="w", padx=10, pady=2)
            
            # Time IN/OUT Display Area
            time_frame = tk.Frame(card_frame, bg=CARD_BG)
            time_frame.pack(fill="x", padx=30, pady=(15, 0))
            
            tk.Label(time_frame, text="SCAN TIME IN:", font=self.bold_text_font, bg=CARD_BG, fg="#333").grid(row=0, column=0, sticky="w")
            self.time_in_val = tk.Label(time_frame, text=card_record["time_in"], font=self.text_font, bg=CARD_BG, fg=SUCCESS_COLOR)
            self.time_in_val.grid(row=0, column=1, sticky="w", padx=10)

            tk.Label(time_frame, text="SCAN TIME OUT:", font=self.bold_text_font, bg=CARD_BG, fg="#333").grid(row=1, column=0, sticky="w", pady=10)
            self.time_out_val = tk.Label(time_frame, text=card_record["time_out"], font=self.text_font, bg=CARD_BG, fg="#F57C00")
            self.time_out_val.grid(row=1, column=1, sticky="w", padx=10, pady=10)
            
            self.status_lbl = tk.Label(card_frame, text=status_text, font=("Segoe UI", 14, "bold"), bg=status_color, fg=FG_MAIN)
            self.status_lbl.pack(fill="x", side="bottom")

        else:
            # Dynamically Update if Window exists
            self.profile_window.title(f"EMPLOYEE ID - {name}")
            
            self.name_label_prof.config(text=name)
            self.empid_label_prof.config(text=user_data.get("id", "N/A"))
            self.pos_label_prof.config(text=user_data.get("position", "N/A"))
            self.uid_label_prof.config(text=uid)
            
            self.time_in_val.config(text=card_record["time_in"])
            self.time_out_val.config(text=card_record["time_out"])
            
            # Micro-Interaction: Blink verify bar
            self.status_lbl.config(bg="#FFF", text="REFRESHING...")
            self.profile_window.after(150, lambda: self.status_lbl.config(bg=status_color, text=status_text))
            
            self.profile_window.lift()

    def prompt_registration(self, uid):
        """Displays registration dialog for unregistered cards."""
        reg_win = tk.Toplevel(self.root)
        reg_win.title("Register New Card")
        reg_win.geometry("500x350")
        reg_win.configure(bg=BG_SEC)
        
        # Grab focus
        reg_win.grab_set()

        tk.Label(reg_win, text=f"New Card Detected: {uid}", font=self.bold_text_font, bg=BG_SEC, fg=ACCENT).pack(pady=15)

        form_frame = tk.Frame(reg_win, bg=BG_SEC)
        form_frame.pack(pady=10, padx=20, fill="x")
        
        # Name Entry
        tk.Label(form_frame, text="Full Name:", font=self.text_font, bg=BG_SEC, fg=FG_MAIN).grid(row=0, column=0, sticky="e", pady=5)
        name_entry = tk.Entry(form_frame, font=self.text_font, width=25, bg="#333", fg=FG_MAIN, insertbackground=FG_MAIN)
        name_entry.grid(row=0, column=1, padx=10, pady=5)
        name_entry.focus_force()

        # ID Entry
        tk.Label(form_frame, text="Employee ID:", font=self.text_font, bg=BG_SEC, fg=FG_MAIN).grid(row=1, column=0, sticky="e", pady=5)
        id_entry = tk.Entry(form_frame, font=self.text_font, width=25, bg="#333", fg=FG_MAIN, insertbackground=FG_MAIN)
        id_entry.grid(row=1, column=1, padx=10, pady=5)

        # Position Entry
        tk.Label(form_frame, text="Position:", font=self.text_font, bg=BG_SEC, fg=FG_MAIN).grid(row=2, column=0, sticky="e", pady=5)
        pos_entry = tk.Entry(form_frame, font=self.text_font, width=25, bg="#333", fg=FG_MAIN, insertbackground=FG_MAIN)
        pos_entry.grid(row=2, column=1, padx=10, pady=5)

        btn_container = tk.Frame(reg_win, bg=BG_SEC)
        btn_container.pack(pady=20)
        
        def save():
            name = name_entry.get().strip()
            emp_id = id_entry.get().strip() or "N/A"
            pos = pos_entry.get().strip() or "N/A"
            
            if name:
                self.users_dictionary[uid] = {
                    "name": name,
                    "id": emp_id,
                    "position": pos
                }
                self.save_users()
                self.status_var.set(f"Successfully Registered:\n{name}")
                reg_win.destroy()
                
                # Fetch full dictionary update state machine for "Time In"
                now = datetime.datetime.now()
                time_str = now.strftime("%m/%d/%Y - %I:%M:%S %p")
                self.attendance_log[uid] = {"state": "IN", "time_in": time_str, "time_out": "--"}
                self.log_scan(uid, name)
                
                # Show
                self.show_profile(uid, name, self.attendance_log[uid], self.users_dictionary[uid])
                self.log_scan(uid, name, emp_id, pos)
                
        def cancel():
            reg_win.destroy()

        reg_btn = tk.Button(btn_container, text="Save & Register", command=save, bg=ACCENT, fg=FG_MAIN, font=self.bold_text_font, relief="flat", padx=15, pady=5)
        reg_btn.pack(side="left", padx=10)
        cancel_btn = tk.Button(btn_container, text="Ignore Tag", command=cancel, bg="#555", fg=FG_MAIN, font=self.bold_text_font, relief="flat", padx=15, pady=5)
        cancel_btn.pack(side="left", padx=10)

        # Bind enter key
        reg_win.bind('<Return>', lambda event: save())
        
        self.root.wait_window(reg_win)

    def prompt_unregister(self):
        """Displays unregistration dialog."""
        unreg_win = tk.Toplevel(self.root)
        unreg_win.title("Unregister Employee")
        unreg_win.geometry("450x250")
        unreg_win.configure(bg=BG_SEC)
        unreg_win.grab_set()

        tk.Label(unreg_win, text="Unregister Employee", font=self.title_font, bg=BG_SEC, fg=ERROR_COLOR).pack(pady=(15, 5))
        tk.Label(unreg_win, text="Enter Employee ID (Card UID):", font=self.text_font, bg=BG_SEC, fg=FG_SEC).pack(pady=5)

        entry_frame = tk.Frame(unreg_win, bg=BG_SEC)
        entry_frame.pack(pady=10)
        
        id_entry = tk.Entry(entry_frame, font=self.heading_font, width=18, bg="#333", fg=FG_MAIN, insertbackground=FG_MAIN, justify="center")
        id_entry.pack()
        id_entry.focus_force()

        btn_container = tk.Frame(unreg_win, bg=BG_SEC)
        btn_container.pack(pady=20)
        
        def confirm():
            uid = id_entry.get().strip().upper()
            if not uid:
                messagebox.showwarning("Input Error", "Please provide a Card UID.")
                return

            if uid in self.users_dictionary:
                user_data = self.users_dictionary[uid]
                name = user_data["name"]
                if messagebox.askyesno("Confirm Unregister", f"Are you sure you want to unregister:\n\n{name}\n({uid})?"):
                    del self.users_dictionary[uid]
                    self.save_users()
                    self.status_var.set(f"Employee Unregistered:\n{name}\nCurrently Tracking: {len(self.users_dictionary)} Employees")
                    messagebox.showinfo("Success", f"Successfully unregistered {name}")
                    unreg_win.destroy()
            else:
                messagebox.showerror("Error", f"Employee ID '{uid}' not found in registry.")

        unreg_btn = tk.Button(btn_container, text="Confirm Unregister", command=confirm, bg=ERROR_COLOR, fg=FG_MAIN, font=self.bold_text_font, relief="flat", padx=15, pady=5)
        unreg_btn.pack(side="left", padx=10)
        cancel_btn = tk.Button(btn_container, text="Cancel", command=unreg_win.destroy, bg="#555", fg=FG_MAIN, font=self.bold_text_font, relief="flat", padx=15, pady=5)
        cancel_btn.pack(side="left", padx=10)

        # Bind Enter key
        unreg_win.bind('<Return>', lambda event: confirm())

    def on_closing(self):
        if self.ser:
            self.ser.close()
        if self.db:
            self.db.close()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = EmployeeRFIDReaderApp(root)
    root.mainloop()
